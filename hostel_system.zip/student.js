// student.js — Student Dashboard Logic

const API = 'api.php';

// ── AUTH CHECK ──────────────────────────────────────────────────────────
const user = JSON.parse(sessionStorage.getItem('user') || 'null');
if (!user || user.role !== 'student') window.location.href = 'index.html';

document.getElementById('stu-name').textContent       = user.full_name;
document.getElementById('stu-avatar-init').textContent = user.full_name.charAt(0).toUpperCase();
document.getElementById('profile-avatar').textContent  = user.full_name.charAt(0).toUpperCase();
document.getElementById('topbar-date').textContent = new Date().toLocaleDateString('en-US', {
  weekday: 'long', year: 'numeric', month: 'long', day: 'numeric'
});

// ── TAB NAVIGATION ──────────────────────────────────────────────────────
document.querySelectorAll('.nav-item').forEach(item => {
  item.addEventListener('click', e => {
    e.preventDefault();
    const tab = item.dataset.tab;
    document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
    document.querySelectorAll('.tab-content').forEach(t => t.classList.remove('active'));
    item.classList.add('active');
    document.getElementById(`tab-${tab}`).classList.add('active');
    document.getElementById('page-title').textContent = item.querySelector('span:last-child').textContent;
    if (tab === 'notices')   loadNotices();
    if (tab === 'requests')  loadMyRequests();
    if (tab === 'profile')   renderProfile();
    if (window.innerWidth < 900) toggleSidebar();
  });
});

// ── INIT ─────────────────────────────────────────────────────────────────
async function init() {
  await loadMyRoom();
}
init();

// ── MY ROOM ──────────────────────────────────────────────────────────────
async function loadMyRoom() {
  const data = await api('my_room');
  const sec  = document.getElementById('room-status-section');

  if (!data.success || !data.room) {
    sec.innerHTML = `
      <div class="no-room-card">
        <div class="big-icon">🔑</div>
        <h3>No Room Assigned Yet</h3>
        <p>Your room has not been allocated. Please contact the hostel rector to get a room assigned to you.</p>
        <div style="margin-top:24px;padding:16px;background:#fef9f0;border-radius:10px;border:1px solid #fed7aa;">
          <p style="font-size:.85rem;color:#92400e">
            <strong>📞 Contact Rector</strong><br>
            Visit the hostel office or email the rector to request room allocation.
          </p>
        </div>
      </div>`;
    return;
  }

  const r   = data.room;
  const pct = r.capacity ? (r.occupied / r.capacity * 100).toFixed(0) : 0;
  sec.innerHTML = `
    <div class="my-room-card">
      <div class="my-room-header">
        <div class="my-room-number">Room ${esc(r.room_number)}</div>
        <div class="my-room-sub">Floor ${r.floor} · ${cap(r.room_type)} Room · Capacity: ${r.capacity}</div>
      </div>
      <div class="my-room-body">
        <div class="room-info-grid">
          <div class="room-info-item">
            <div class="info-label">Room Number</div>
            <div class="info-val">Room ${esc(r.room_number)}</div>
          </div>
          <div class="room-info-item">
            <div class="info-label">Floor</div>
            <div class="info-val">Floor ${r.floor}</div>
          </div>
          <div class="room-info-item">
            <div class="info-label">Room Type</div>
            <div class="info-val">${cap(r.room_type)}</div>
          </div>
          <div class="room-info-item">
            <div class="info-label">Allocated On</div>
            <div class="info-val">${fmt(r.allocated_date)}</div>
          </div>
          <div class="room-info-item">
            <div class="info-label">Allocated By</div>
            <div class="info-val">${esc(r.rector_name)}</div>
          </div>
          <div class="room-info-item">
            <div class="info-label">Occupancy</div>
            <div class="info-val">${r.occupied} / ${r.capacity} beds</div>
          </div>
        </div>
        <div style="margin-bottom:20px">
          <div class="info-label" style="margin-bottom:8px">Amenities</div>
          <div style="display:flex;flex-wrap:wrap;gap:8px">
            ${(r.amenities || 'None').split(',').map(a => `<span style="background:#f1f5f9;padding:4px 12px;border-radius:999px;font-size:.82rem;color:var(--navy-3)">${esc(a.trim())}</span>`).join('')}
          </div>
        </div>
        ${r.notes ? `<div style="background:#fef9f0;border:1px solid #fed7aa;border-radius:10px;padding:14px 16px;font-size:.88rem;color:#92400e"><strong>📝 Notes from Rector:</strong><br>${esc(r.notes)}</div>` : ''}
        <div style="margin-top:20px;padding-top:16px;border-top:1px solid var(--border)">
          <button class="btn btn-primary" onclick="switchTab('requests')">💬 Submit a Complaint / Request</button>
        </div>
      </div>
    </div>

    <div style="background:white;border-radius:12px;padding:20px;box-shadow:var(--shadow);max-width:680px">
      <h3 style="font-family:var(--font-display);color:var(--navy);margin-bottom:12px">Occupancy</h3>
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px">
        <span style="font-size:.85rem;color:var(--slate)">${r.occupied} of ${r.capacity} beds occupied</span>
        <span style="font-size:.85rem;font-weight:700;color:var(--navy)">${pct}%</span>
      </div>
      <div class="occ-bar-wrap" style="height:8px">
        <div class="occ-bar" style="width:${pct}%;background:${pct >= 100 ? 'var(--danger)' : pct > 60 ? 'var(--warn)' : 'var(--success)'}"></div>
      </div>
    </div>`;
}

function switchTab(tabName) {
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
  document.querySelectorAll('.tab-content').forEach(t => t.classList.remove('active'));
  document.querySelector(`.nav-item[data-tab="${tabName}"]`).classList.add('active');
  document.getElementById(`tab-${tabName}`).classList.add('active');
  document.getElementById('page-title').textContent = 'My Requests';
  loadMyRequests();
}

// ── NOTICES ──────────────────────────────────────────────────────────────
async function loadNotices() {
  const data = await api('get_notices');
  const feed = document.getElementById('notices-list');
  if (!data.success || !data.notices.length) {
    feed.innerHTML = '<p style="color:var(--muted);text-align:center;padding:40px">No notices posted yet.</p>';
    return;
  }
  feed.innerHTML = data.notices.map(n => `
    <div class="notice-item">
      <div class="notice-title">${esc(n.title)}</div>
      <p class="notice-body">${esc(n.content)}</p>
      <div class="notice-footer">
        <span class="notice-date">📢 ${esc(n.posted_by_name)} · ${fmtDt(n.created_at)}</span>
      </div>
    </div>`).join('');
}

// ── REQUESTS ─────────────────────────────────────────────────────────────
async function loadMyRequests() {
  const data = await api('my_requests');
  const feed = document.getElementById('my-requests-list');
  if (!data.success || !data.requests.length) {
    feed.innerHTML = `
      <div style="text-align:center;padding:60px 20px;background:white;border-radius:12px;box-shadow:var(--shadow)">
        <div style="font-size:3rem;margin-bottom:12px">💬</div>
        <h3 style="color:var(--navy);font-family:var(--font-display)">No Requests Yet</h3>
        <p style="color:var(--slate);margin:8px 0 20px">Submit a maintenance request or complaint to the rector.</p>
        <button class="btn btn-primary" onclick="openModal('new-request-modal')">+ New Request</button>
      </div>`;
    return;
  }
  feed.innerHTML = data.requests.map(r => `
    <div class="request-item ${r.status}">
      <div class="req-header">
        <div>
          <div class="req-subject">${esc(r.subject)}</div>
          <div class="req-meta">${fmtDt(r.created_at)}</div>
        </div>
        <span class="pill ${statusPill(r.status)}">${r.status.replace('_',' ')}</span>
      </div>
      <p class="req-message">${esc(r.message)}</p>
      ${r.rector_response ? `
        <div class="req-response">
          <strong>✅ Rector's Response:</strong>
          ${esc(r.rector_response)}
        </div>` : '<p style="font-size:.82rem;color:var(--muted);margin-top:8px">⏳ Awaiting response from rector...</p>'}
    </div>`).join('');
}

async function submitRequest() {
  const subject = document.getElementById('req-subject').value;
  const message = document.getElementById('req-message').value.trim();
  const err     = document.getElementById('req-modal-err');

  if (!subject || !message) { err.textContent = 'Please fill in all fields'; err.classList.remove('hidden'); return; }
  err.classList.add('hidden');

  const data = await api('submit_request', { subject, message });
  if (data.success) {
    closeModal('new-request-modal');
    document.getElementById('req-subject').value = '';
    document.getElementById('req-message').value = '';
    showToast('Request submitted! 🎉', 'success');
    loadMyRequests();
  } else {
    err.textContent = data.message;
    err.classList.remove('hidden');
  }
}

// ── PROFILE ──────────────────────────────────────────────────────────────
function renderProfile() {
  const el = document.getElementById('profile-details');
  el.innerHTML = `
    <div class="profile-item">
      <div class="p-label">Full Name</div>
      <div class="p-val">${esc(user.full_name)}</div>
    </div>
    <div class="profile-item">
      <div class="p-label">Student ID</div>
      <div class="p-val">${esc(user.student_id || '—')}</div>
    </div>
    <div class="profile-item full-width">
      <div class="p-label">Email</div>
      <div class="p-val">${esc(user.email)}</div>
    </div>
    <div class="profile-item">
      <div class="p-label">Course</div>
      <div class="p-val">${esc(user.course || '—')}</div>
    </div>
    <div class="profile-item">
      <div class="p-label">Year of Study</div>
      <div class="p-val">${user.year_of_study ? `Year ${user.year_of_study}` : '—'}</div>
    </div>`;
}

// ── UTIL ─────────────────────────────────────────────────────────────────
async function api(action, body = null) {
  const opts = { method: body ? 'POST' : 'GET', headers: { 'Content-Type': 'application/json' } };
  if (body) opts.body = JSON.stringify(body);
  const res = await fetch(`${API}?action=${action}`, opts);
  return res.json();
}

function esc(str) {
  if (!str) return '';
  return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
function cap(str) { return str ? str.charAt(0).toUpperCase() + str.slice(1) : ''; }
function fmt(d) { return d ? new Date(d).toLocaleDateString('en-GB', { day:'2-digit', month:'short', year:'numeric' }) : '—'; }
function fmtDt(d){ return d ? new Date(d).toLocaleDateString('en-GB', { day:'2-digit', month:'short', year:'numeric', hour:'2-digit', minute:'2-digit' }) : '—'; }
function statusPill(s) { return { pending:'pill-yellow', in_progress:'pill-blue', resolved:'pill-green' }[s] || 'pill-gray'; }

function openModal(id) {
  document.getElementById(id).classList.add('open');
  document.body.style.overflow = 'hidden';
}
function closeModal(id) {
  document.getElementById(id).classList.remove('open');
  document.body.style.overflow = '';
}
document.querySelectorAll('.modal-overlay').forEach(overlay => {
  overlay.addEventListener('click', e => {
    if (e.target === overlay) closeModal(overlay.id);
  });
});
function showToast(msg, type = '') {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.className = `toast ${type}`;
  t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), 3200);
}
function toggleSidebar() {
  document.getElementById('sidebar').classList.toggle('open');
}
async function logout() {
  await fetch(`${API}?action=logout`);
  sessionStorage.clear();
  window.location.href = 'index.html';
}
