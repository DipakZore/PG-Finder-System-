# 🏛 Hostel Management System

A full-stack hostel management system with Student and Rector roles.

---

## 📁 File Structure

```
hostel_system/
├── index.html      ← Login page
├── rector.html     ← Rector dashboard
├── student.html    ← Student dashboard
├── style.css       ← All styles
├── rector.js       ← Rector frontend logic
├── student.js      ← Student frontend logic
├── api.php         ← Backend REST API
├── db.php          ← Database connection & helpers
├── setup.sql       ← Database schema + seed data
└── README.md       ← This file
```

---

## 🚀 HOW TO RUN (Step-by-Step)

### OPTION 1: Using XAMPP (Recommended for Windows/Mac)

#### Step 1 — Install XAMPP
Download from: https://www.apachefriends.org/
Install it (default settings are fine).

#### Step 2 — Start Apache & MySQL
Open XAMPP Control Panel → Click **Start** next to:
- Apache
- MySQL

#### Step 3 — Copy Project Files
Copy the entire `hostel_system/` folder to:
```
Windows: C:\xampp\htdocs\hostel_system\
Mac:     /Applications/XAMPP/htdocs/hostel_system/
```

#### Step 4 — Create the Database
1. Open your browser → go to: http://localhost/phpmyadmin
2. Click **"New"** in the left sidebar
3. Type `hostel_db` → Click **Create**
4. Click on `hostel_db` → Click the **SQL** tab
5. Open `setup.sql` in a text editor, copy ALL contents
6. Paste into the SQL box → Click **Go**

#### Step 5 — Run the App
Open browser → go to:
```
http://localhost/hostel_system/index.html
```

---

### OPTION 2: Using WAMP (Windows)

#### Step 1 — Install WAMP
Download from: https://www.wampserver.com/
Install and launch it (icon appears in system tray).

#### Step 2 — Start Services
Left-click the WAMP tray icon → Click "Start All Services"
Wait until the icon turns GREEN.

#### Step 3 — Copy Files
Place the `hostel_system/` folder in:
```
C:\wamp64\www\hostel_system\
```

#### Step 4 — Create Database
Go to http://localhost/phpmyadmin → Follow same steps as XAMPP Option 1.

#### Step 5 — Open App
```
http://localhost/hostel_system/index.html
```

---

### OPTION 3: PHP Built-in Server (Mac/Linux/Windows with PHP)

#### Requirements
- PHP 7.4+ installed
- MySQL installed and running

#### Step 1 — Create Database
```bash
mysql -u root -p
# (enter your password, or just press Enter if no password)

CREATE DATABASE hostel_db;
USE hostel_db;
SOURCE /path/to/hostel_system/setup.sql;
EXIT;
```

#### Step 2 — Configure DB Password (if needed)
Open `db.php` and update:
```php
define('DB_PASS', 'your_mysql_password');
```

#### Step 3 — Start PHP Server
```bash
cd /path/to/hostel_system
php -S localhost:8000
```

#### Step 4 — Open App
```
http://localhost:8000/index.html
```

---

### OPTION 4: Using MAMP (Mac)

#### Step 1 — Install MAMP
Download from: https://www.mamp.info/
Install and open MAMP.

#### Step 2 — Start Servers
Click **"Start Servers"** in MAMP.

#### Step 3 — Copy Files
Place folder in:
```
/Applications/MAMP/htdocs/hostel_system/
```

#### Step 4 — Create Database
Go to: http://localhost:8888/phpmyadmin
Follow same database creation steps.

#### Step 5 — Open App
```
http://localhost:8888/hostel_system/index.html
```

---

## 🔐 Demo Login Credentials

### Rector (Admin)
| Field    | Value              |
|----------|--------------------|
| Email    | rector@hostel.com  |
| Password | rector123          |

### Students (any of these)
| Email             | Password   |
|-------------------|------------|
| alice@student.com | student123 |
| bob@student.com   | student123 |
| carol@student.com | student123 |
| david@student.com | student123 |
| eve@student.com   | student123 |

---

## ✨ Features

### Rector Dashboard
- 📊 Dashboard with live stats (total students, rooms, allocations, pending requests)
- 🚪 Room Management — Add, delete, set maintenance status, view occupancy
- 🎓 Student Management — Add/remove students, view allocation status
- 🔑 Room Allocation — Assign rooms to students, deallocate rooms
- 💬 Requests — View and respond to student complaints/requests
- 📢 Notice Board — Post and delete notices

### Student Dashboard
- 🏠 My Room — View allocated room details, floor, amenities, occupancy
- 📢 Notice Board — Read all notices from the rector
- 💬 Requests — Submit maintenance/complaint requests, track status + rector responses
- 👤 Profile — View personal information

---

## 🛠 Troubleshooting

**"Database connection failed"**
→ Make sure MySQL is running in XAMPP/WAMP
→ Check DB_PASS in db.php matches your MySQL password

**"Unknown action" error**
→ Make sure all files are in the same folder
→ Make sure Apache is running

**Login not working after creating DB**
→ The seed data uses bcrypt hashed passwords
→ If that fails, manually update passwords in phpMyAdmin:
```sql
UPDATE users SET password = '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi' WHERE 1;
```
→ This sets everyone's password to `password` — or use `password_hash()` in PHP CLI

**White page / JS errors**
→ Open browser DevTools (F12) → Console tab to see errors
→ Make sure you're accessing via http://localhost/... not file:///

---

## 🔒 Security Note
This is a demonstration system. For production use, add:
- CSRF tokens
- Input sanitization
- Rate limiting
- HTTPS
- Stronger session management
