// rector.js — Rector Dashboard Logic

const API = 'api.php';
let allRooms = [], allStudents = [], allAllocations = [];

// ── AUTH CHECK ──────────────────────────────────────────────────────────
const user = JSON.parse(sessionStorage.getItem('user') || 'null');
if (!user || user.role !== 'rector') window.location.href = 'index.html';

document.getElementById('rector-name').textContent = user.full_name;
document.getElementById('topbar-date').textContent = new Date().toLocaleDateString('en-US', {
  weekday: 'long', year: 'numeric', month: 'long', day: 'numeric'
});

// ── TAB NAVIGATION ──────────────────────────────────────────────────────
document.querySelectorAll('.nav-item').forEach(item => {
  item.addEventListener('click', e => {
    e.preventDefault();
    const tab = item.dataset.tab;
    document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
    document.querySelectorAll('.tab-content').forEach(t => t.classList.remove('active'));
    item.classList.add('active');
    document.getElementById(`tab-${tab}`).classList.add('active');
    document.getElementById('page-title').textContent = item.querySelector('span:last-child').textContent;
    if (tab === 'rooms')       loadRooms();
    if (tab === 'students')    loadStudents();
    if (tab === 'allocations') loadAllocations();
    if (tab === 'requests')    loadRequests();
    if (tab === 'notices')     loadNotices();
    if (window.innerWidth < 900) toggleSidebar();
  });
});

// ── INIT ────────────────────────────────────────────────────────────────
async function init() {
  await Promise.all([loadStats(), loadDashNotices(), loadStudentSelect(), loadRoomSelect()]);
}
init();

// ── STATS ────────────────────────────────────────────────────────────────
async function loadStats() {
  const data = await api('stats');
  if (!data.success) return;
  const s = data.stats;
  document.getElementById('stat-students').textContent    = s.total_students;
  document.getElementById('stat-available').textContent   = s.available_rooms;
  document.getElementById('stat-allocations').textContent = s.active_allocations;
  document.getElementById('stat-pending').textContent     = s.pending_requests;
  document.getElementById('stat-rooms').textContent       = s.total_rooms;
  document.getElementById('stat-unallocated').textContent = s.unallocated;
  const badge = document.getElementById('req-badge');
  badge.textContent = s.pending_requests;
  badge.style.display = s.pending_requests > 0 ? 'inline' : 'none';
}

// ── DASHBOARD NOTICES ───────────────────────────────────────────────────
async function loadDashNotices() {
  const data = await api('get_notices');
  const el   = document.getElementById('dash-notices');
  if (!data.success || !data.notices.length) { el.innerHTML = '<p style="color:var(--muted);font-size:.85rem">No notices yet.</p>'; return; }
  el.innerHTML = data.notices.slice(0,3).map(n => `
    <div class="notice-sm">
      <strong>${esc(n.title)}</strong>
      <p>${esc(n.content.slice(0,80))}${n.content.length > 80 ? '...' : ''}</p>
    </div>`).join('');
}

// ── SELECT HELPERS ──────────────────────────────────────────────────────
async function loadStudentSelect() {
  const data = await api('get_students');
  if (!data.success) return;
  allStudents = data.students;
  const unalloc = data.students.filter(s => !s.room_number);
  ['qk-student','al-student'].forEach(id => {
    const sel = document.getElementById(id);
    if (!sel) return;
    sel.innerHTML = '<option value="">— Select Student —</option>';
    unalloc.forEach(s => {
      sel.innerHTML += `<option value="${s.id}">${esc(s.full_name)} (${esc(s.student_id)})</option>`;
    });
  });
}

async function loadRoomSelect() {
  const data = await api('get_rooms');
  if (!data.success) return;
  allRooms = data.rooms;
  const avail = data.rooms.filter(r => r.status === 'available');
  ['qk-room','al-room'].forEach(id => {
    const sel = document.getElementById(id);
    if (!sel) return;
    sel.innerHTML = '<option value="">— Select Room —</option>';
    avail.forEach(r => {
      sel.innerHTML += `<option value="${r.id}">Room ${esc(r.room_number)} — Floor ${r.floor} — ${cap(r.type)} (${r.occupied}/${r.capacity})</option>`;
    });
  });
}

// ── ROOMS ────────────────────────────────────────────────────────────────
async function loadRooms() {
  const data = await api('get_rooms');
  if (!data.success) return;
  allRooms = data.rooms;
  renderRooms(allRooms);
}

function renderRooms(rooms) {
  const grid = document.getElementById('rooms-grid');
  if (!rooms.length) { grid.innerHTML = '<p style="color:var(--muted);padding:20px">No rooms found.</p>'; return; }
  grid.innerHTML = rooms.map(r => {
    const pct  = r.capacity ? (r.occupied / r.capacity * 100) : 0;
    const badge = { available: 'badge-available', full: 'badge-full', maintenance: 'badge-maintenance' }[r.status];
    return `
    <div class="room-card">
      <div class="room-card-top">
        <div class="room-number">Room ${esc(r.room_number)}</div>
        <div class="room-floor">Floor ${r.floor}</div>
        <span class="room-badge ${badge}">${r.status}</span>
      </div>
      <div class="room-card-body">
        <div class="room-meta">
          <span class="room-type">${cap(r.type)}</span>
          <span class="room-occ">${r.occupied}/${r.capacity} occupied</span>
        </div>
        <div class="occ-bar-wrap">
          <div class="occ-bar" style="width:${pct}%; background:${pct >= 100 ? 'var(--danger)' : pct > 50 ? 'var(--warn)' : 'var(--success)'}"></div>
        </div>
        <div class="room-amenities">${esc(r.amenities || 'No amenities listed')}</div>
        <div class="room-actions">
          ${r.status !== 'maintenance' ? `<button class="btn btn-sm btn-secondary" onclick="setMaintenance(${r.id})">🔧 Maintenance</button>` : `<button class="btn btn-sm btn-success" onclick="setAvailable(${r.id})">✓ Set Available</button>`}
          ${r.occupied === 0 ? `<button class="btn btn-sm btn-danger" onclick="deleteRoom(${r.id})">🗑 Delete</button>` : ''}
        </div>
      </div>
    </div>`;
  }).join('');
}

function filterRooms() {
  const q      = document.getElementById('room-search').value.toLowerCase();
  const status = document.getElementById('room-filter-status').value;
  const type   = document.getElementById('room-filter-type').value;
  const filtered = allRooms.filter(r =>
    (!q      || r.room_number.toLowerCase().includes(q) || (r.amenities||'').toLowerCase().includes(q)) &&
    (!status || r.status === status) &&
    (!type   || r.type === type)
  );
  renderRooms(filtered);
}

async function addRoom() {
  const room_number = document.getElementById('nr-number').value.trim();
  const floor       = document.getElementById('nr-floor').value;
  const type        = document.getElementById('nr-type').value;
  const capacity    = document.getElementById('nr-capacity').value;
  const amenities   = document.getElementById('nr-amenities').value.trim();
  const err         = document.getElementById('room-modal-err');

  if (!room_number) { err.textContent = 'Room number is required'; err.classList.remove('hidden'); return; }
  err.classList.add('hidden');

  const data = await api('add_room', { room_number, floor: +floor, type, capacity: +capacity, amenities });
  if (data.success) {
    closeModal('add-room-modal');
    showToast('Room added successfully', 'success');
    loadRooms();
    loadRoomSelect();
    loadStats();
  } else {
    err.textContent = data.message;
    err.classList.remove('hidden');
  }
}

async function setMaintenance(id) {
  await api('update_room_status', { room_id: id, status: 'maintenance' });
  loadRooms(); loadStats();
  showToast('Room set to maintenance');
}
async function setAvailable(id) {
  await api('update_room_status', { room_id: id, status: 'available' });
  loadRooms(); loadStats(); loadRoomSelect();
  showToast('Room set to available', 'success');
}
async function deleteRoom(id) {
  if (!confirm('Delete this room?')) return;
  const data = await api('delete_room', { room_id: id });
  if (data.success) { loadRooms(); loadStats(); showToast('Room deleted'); }
  else showToast(data.message, 'error');
}

function updateCapacity() {
  const t = document.getElementById('nr-type').value;
  document.getElementById('nr-capacity').value = { single:1, double:2, triple:3 }[t];
}

// ── STUDENTS ─────────────────────────────────────────────────────────────
async function loadStudents() {
  const data = await api('get_students');
  if (!data.success) return;
  allStudents = data.students;
  renderStudents(allStudents);
}

function renderStudents(students) {
  const tbody = document.getElementById('students-tbody');
  if (!students.length) { tbody.innerHTML = '<tr><td colspan="7" class="loading-row">No students found.</td></tr>'; return; }
  tbody.innerHTML = students.map(s => `
    <tr>
      <td><strong>${esc(s.student_id)}</strong></td>
      <td>${esc(s.full_name)}<br><small style="color:var(--muted)">${esc(s.email)}</small></td>
      <td>${esc(s.course || '—')}</td>
      <td>${s.year_of_study || '—'}</td>
      <td>${s.room_number ? `<strong>Room ${esc(s.room_number)}</strong><br><small style="color:var(--muted)">Floor ${s.floor} · ${cap(s.room_type)}</small>` : '<span style="color:var(--muted)">Not Allocated</span>'}</td>
      <td>${s.room_number ? '<span class="pill pill-green">Allocated</span>' : '<span class="pill pill-yellow">Pending</span>'}</td>
      <td>
        <div class="table-actions">
          ${!s.room_number ? `<button class="btn btn-sm btn-primary" onclick="openAllocateFor(${s.id})">Assign Room</button>` : `<button class="btn btn-sm btn-danger" onclick="deallocateStudent(${s.allocation_id}, '${esc(s.full_name)}')">Remove</button>`}
          <button class="btn btn-sm btn-danger" onclick="deleteStudent(${s.id})">🗑</button>
        </div>
      </td>
    </tr>`).join('');
}

function filterStudents() {
  const q = document.getElementById('student-search').value.toLowerCase();
  const filtered = allStudents.filter(s =>
    s.full_name.toLowerCase().includes(q) ||
    (s.student_id||'').toLowerCase().includes(q) ||
    (s.email||'').toLowerCase().includes(q) ||
    (s.course||'').toLowerCase().includes(q)
  );
  renderStudents(filtered);
}

async function addStudent() {
  const full_name    = document.getElementById('ns-name').value.trim();
  const student_id   = document.getElementById('ns-sid').value.trim();
  const email        = document.getElementById('ns-email').value.trim();
  const phone        = document.getElementById('ns-phone').value.trim();
  const course       = document.getElementById('ns-course').value.trim();
  const year_of_study= document.getElementById('ns-year').value;
  const password     = document.getElementById('ns-pass').value || 'student123';
  const err          = document.getElementById('student-modal-err');

  if (!full_name || !email || !student_id) { err.textContent = 'Name, email and student ID required'; err.classList.remove('hidden'); return; }
  err.classList.add('hidden');

  const data = await api('add_student', { full_name, student_id, email, phone, course, year_of_study: +year_of_study, password });
  if (data.success) {
    closeModal('add-student-modal');
    showToast('Student added', 'success');
    loadStudents(); loadStudentSelect(); loadStats();
  } else {
    err.textContent = data.message;
    err.classList.remove('hidden');
  }
}

async function deleteStudent(id) {
  if (!confirm('Remove this student? This will also remove their room allocation.')) return;
  await api('delete_student', { student_id: id });
  loadStudents(); loadStudentSelect(); loadStats();
  showToast('Student removed');
}

function openAllocateFor(studentId) {
  document.getElementById('al-student').value = studentId;
  document.getElementById('al-date').value = today();
  openModal('allocate-modal');
}

// ── ALLOCATIONS ──────────────────────────────────────────────────────────
async function loadAllocations() {
  const data = await api('get_allocations');
  if (!data.success) return;
  allAllocations = data.allocations;
  const tbody = document.getElementById('alloc-tbody');
  if (!data.allocations.length) { tbody.innerHTML = '<tr><td colspan="8" class="loading-row">No allocations yet.</td></tr>'; return; }
  tbody.innerHTML = data.allocations.map(a => `
    <tr>
      <td><strong>${esc(a.full_name)}</strong></td>
      <td>${esc(a.stu_id)}</td>
      <td><strong>Room ${esc(a.room_number)}</strong></td>
      <td>Floor ${a.floor}</td>
      <td>${cap(a.room_type)}</td>
      <td>${fmt(a.allocated_date)}</td>
      <td>${a.status === 'active' ? '<span class="pill pill-green">Active</span>' : '<span class="pill pill-gray">Vacated</span>'}</td>
      <td>${a.status === 'active' ? `<button class="btn btn-sm btn-danger" onclick="deallocate(${a.id})">Deallocate</button>` : `<span style="color:var(--muted);font-size:.8rem">${fmt(a.check_out_date)}</span>`}</td>
    </tr>`).join('');
}

async function allocateRoom() {
  const student_id     = document.getElementById('al-student').value;
  const room_id        = document.getElementById('al-room').value;
  const allocated_date = document.getElementById('al-date').value || today();
  const notes          = document.getElementById('al-notes').value.trim();
  const err            = document.getElementById('alloc-modal-err');

  if (!student_id || !room_id) { err.textContent = 'Please select both student and room'; err.classList.remove('hidden'); return; }
  err.classList.add('hidden');

  const data = await api('allocate_room', { student_id: +student_id, room_id: +room_id, allocated_date, notes });
  if (data.success) {
    closeModal('allocate-modal');
    showToast('Room allocated successfully! 🎉', 'success');
    loadStudents(); loadAllocations(); loadRoomSelect(); loadStudentSelect(); loadStats();
  } else {
    err.textContent = data.message;
    err.classList.remove('hidden');
  }
}

async function quickAllocate() {
  const student_id = document.getElementById('qk-student').value;
  const room_id    = document.getElementById('qk-room').value;
  if (!student_id || !room_id) { showToast('Select both student and room', 'error'); return; }
  const data = await api('allocate_room', { student_id: +student_id, room_id: +room_id, allocated_date: today() });
  if (data.success) {
    showToast('Room allocated! 🎉', 'success');
    loadStudentSelect(); loadRoomSelect(); loadStats(); loadDashNotices();
  } else {
    showToast(data.message, 'error');
  }
}

async function deallocate(allocationId) {
  if (!confirm('Remove this room allocation?')) return;
  const data = await api('deallocate_room', { allocation_id: allocationId });
  if (data.success) {
    showToast('Room deallocated', 'success');
    loadAllocations(); loadStudents(); loadRoomSelect(); loadStudentSelect(); loadStats();
  } else showToast(data.message, 'error');
}

async function deallocateStudent(allocationId, name) {
  if (!confirm(`Remove room allocation for ${name}?`)) return;
  const data = await api('deallocate_room', { allocation_id: allocationId });
  if (data.success) {
    showToast('Room deallocated', 'success');
    loadStudents(); loadRoomSelect(); loadStudentSelect(); loadStats();
  }
}

// ── REQUESTS ─────────────────────────────────────────────────────────────
async function loadRequests() {
  const data = await api('get_all_requests');
  const feed = document.getElementById('requests-list');
  if (!data.success || !data.requests.length) { feed.innerHTML = '<p style="color:var(--muted);padding:20px;text-align:center">No requests yet.</p>'; return; }
  feed.innerHTML = data.requests.map(r => `
    <div class="request-item ${r.status}">
      <div class="req-header">
        <div>
          <div class="req-subject">${esc(r.subject)}</div>
          <div class="req-meta">From: <strong>${esc(r.full_name)}</strong> (${esc(r.stu_id)}) · ${fmtDt(r.created_at)}</div>
        </div>
        <span class="pill ${statusPill(r.status)}">${r.status.replace('_',' ')}</span>
      </div>
      <p class="req-message">${esc(r.message)}</p>
      ${r.rector_response ? `<div class="req-response"><strong>Your Response:</strong>${esc(r.rector_response)}</div>` : ''}
      ${r.status !== 'resolved' ? `<div style="margin-top:12px"><button class="btn btn-sm btn-primary" onclick="openRespond(${r.id}, '${esc(r.subject)}', '${esc(r.message).replace(/'/g,"\\'")}')">Respond</button></div>` : ''}
    </div>`).join('');
}

function openRespond(id, subject, message) {
  document.getElementById('respond-req-id').value = id;
  document.getElementById('respond-req-detail').innerHTML = `<strong>${esc(subject)}</strong>${esc(message)}`;
  document.getElementById('respond-text').value = '';
  openModal('respond-modal');
}

async function sendResponse() {
  const req_id   = document.getElementById('respond-req-id').value;
  const response = document.getElementById('respond-text').value.trim();
  const status   = document.getElementById('respond-status').value;
  if (!response) { showToast('Please write a response', 'error'); return; }
  const data = await api('respond_request', { request_id: +req_id, response, status });
  if (data.success) {
    closeModal('respond-modal');
    showToast('Response sent', 'success');
    loadRequests(); loadStats();
  }
}

// ── NOTICES ──────────────────────────────────────────────────────────────
async function loadNotices() {
  const data = await api('get_notices');
  const feed = document.getElementById('notices-list');
  if (!data.success || !data.notices.length) { feed.innerHTML = '<p style="color:var(--muted);padding:20px;text-align:center">No notices posted yet.</p>'; return; }
  feed.innerHTML = data.notices.map(n => `
    <div class="notice-item">
      <div class="notice-title">${esc(n.title)}</div>
      <p class="notice-body">${esc(n.content)}</p>
      <div class="notice-footer">
        <span class="notice-date">Posted by ${esc(n.posted_by_name)} · ${fmtDt(n.created_at)}</span>
        <button class="btn btn-sm btn-danger" onclick="deleteNotice(${n.id})">Delete</button>
      </div>
    </div>`).join('');
}

async function postNotice() {
  const title   = document.getElementById('nn-title').value.trim();
  const content = document.getElementById('nn-content').value.trim();
  if (!title || !content) { showToast('Title and content required', 'error'); return; }
  const data = await api('post_notice', { title, content });
  if (data.success) {
    closeModal('add-notice-modal');
    document.getElementById('nn-title').value = '';
    document.getElementById('nn-content').value = '';
    showToast('Notice posted', 'success');
    loadNotices(); loadDashNotices();
  }
}

async function deleteNotice(id) {
  if (!confirm('Delete this notice?')) return;
  await api('delete_notice', { notice_id: id });
  loadNotices(); loadDashNotices();
  showToast('Notice deleted');
}

// ── ALLOC MODAL INIT ────────────────────────────────────────────────────
function openAllocateModal() {
  document.getElementById('al-date').value = today();
  openModal('allocate-modal');
}

document.querySelectorAll('[data-tab="allocations"]').forEach(btn => {
  btn.addEventListener('click', () => {
    document.getElementById('al-date').value = today();
  });
});

// ── UTIL ─────────────────────────────────────────────────────────────────
async function api(action, body = null) {
  const opts = { method: body ? 'POST' : 'GET', headers: { 'Content-Type': 'application/json' } };
  if (body) opts.body = JSON.stringify(body);
  const res  = await fetch(`${API}?action=${action}`, opts);
  return res.json();
}

function esc(str) {
  if (!str) return '';
  return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
function cap(str) { return str ? str.charAt(0).toUpperCase() + str.slice(1) : ''; }
function today() { return new Date().toISOString().split('T')[0]; }
function fmt(d)  { return d ? new Date(d).toLocaleDateString('en-GB', { day:'2-digit', month:'short', year:'numeric' }) : '—'; }
function fmtDt(d){ return d ? new Date(d).toLocaleDateString('en-GB', { day:'2-digit', month:'short', year:'numeric', hour:'2-digit', minute:'2-digit' }) : '—'; }
function statusPill(s) { return { pending:'pill-yellow', in_progress:'pill-blue', resolved:'pill-green' }[s] || 'pill-gray'; }

function openModal(id) {
  document.getElementById(id).classList.add('open');
  document.body.style.overflow = 'hidden';
}
function closeModal(id) {
  document.getElementById(id).classList.remove('open');
  document.body.style.overflow = '';
}

// Close modal on overlay click
document.querySelectorAll('.modal-overlay').forEach(overlay => {
  overlay.addEventListener('click', e => {
    if (e.target === overlay) closeModal(overlay.id);
  });
});

function showToast(msg, type = '') {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.className = `toast ${type}`;
  t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), 3200);
}

function toggleSidebar() {
  document.getElementById('sidebar').classList.toggle('open');
}

async function logout() {
  await fetch(`${API}?action=logout`);
  sessionStorage.clear();
  window.location.href = 'index.html';
}
