<?php
// api.php — Main API Handler

session_start();
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, DELETE');
header('Access-Control-Allow-Headers: Content-Type');

require_once 'db.php';

$action = $_GET['action'] ?? $_POST['action'] ?? '';
$method = $_SERVER['REQUEST_METHOD'];

// For JSON body requests
$input = json_decode(file_get_contents('php://input'), true) ?? [];

switch ($action) {

    // ─── AUTH ───────────────────────────────────────────────────────────
    case 'login':
        $email    = trim($input['email'] ?? '');
        $password = $input['password'] ?? '';
        if (!$email || !$password) jsonResponse(['success' => false, 'message' => 'Email and password required'], 400);

        $db   = getDB();
        $stmt = $db->prepare("SELECT id, full_name, email, password, role, student_id, phone, course, year_of_study FROM users WHERE email = ?");
        $stmt->bind_param('s', $email);
        $stmt->execute();
        $user = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if (!$user || !password_verify($password, $user['password'])) {
            // Also try plain text match for demo seeds
            if (!$user || $user['password'] !== $password) {
                jsonResponse(['success' => false, 'message' => 'Invalid email or password'], 401);
            }
        }

        $_SESSION['user_id']   = $user['id'];
        $_SESSION['role']      = $user['role'];
        $_SESSION['full_name'] = $user['full_name'];

        unset($user['password']);
        jsonResponse(['success' => true, 'user' => $user]);

    case 'logout':
        session_destroy();
        jsonResponse(['success' => true, 'message' => 'Logged out']);

    case 'me':
        requireLogin();
        $db   = getDB();
        $stmt = $db->prepare("SELECT id, full_name, email, role, student_id, phone, course, year_of_study FROM users WHERE id = ?");
        $stmt->bind_param('i', $_SESSION['user_id']);
        $stmt->execute();
        $user = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        jsonResponse(['success' => true, 'user' => $user]);

    // ─── ROOMS ──────────────────────────────────────────────────────────
    case 'get_rooms':
        requireLogin();
        $db     = getDB();
        $result = $db->query("SELECT * FROM rooms ORDER BY floor, room_number");
        $rooms  = $result->fetch_all(MYSQLI_ASSOC);
        $db->close();
        jsonResponse(['success' => true, 'rooms' => $rooms]);

    case 'add_room':
        requireRole('rector');
        $room_number = trim($input['room_number'] ?? '');
        $floor       = intval($input['floor'] ?? 1);
        $type        = $input['type'] ?? 'single';
        $capacity    = intval($input['capacity'] ?? 1);
        $amenities   = trim($input['amenities'] ?? '');

        if (!$room_number) jsonResponse(['success' => false, 'message' => 'Room number required'], 400);

        $db   = getDB();
        $stmt = $db->prepare("INSERT INTO rooms (room_number, floor, type, capacity, amenities) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param('siiss', $room_number, $floor, $type, $capacity, $amenities);
        if ($stmt->execute()) {
            jsonResponse(['success' => true, 'message' => 'Room added successfully', 'id' => $db->insert_id]);
        } else {
            jsonResponse(['success' => false, 'message' => 'Room number already exists'], 409);
        }

    case 'update_room_status':
        requireRole('rector');
        $room_id = intval($input['room_id'] ?? 0);
        $status  = $input['status'] ?? '';
        if (!$room_id || !in_array($status, ['available', 'maintenance'])) {
            jsonResponse(['success' => false, 'message' => 'Invalid input'], 400);
        }
        $db   = getDB();
        $stmt = $db->prepare("UPDATE rooms SET status = ? WHERE id = ?");
        $stmt->bind_param('si', $status, $room_id);
        $stmt->execute();
        jsonResponse(['success' => true, 'message' => 'Room status updated']);

    case 'delete_room':
        requireRole('rector');
        $room_id = intval($input['room_id'] ?? 0);
        $db      = getDB();
        // Check no active allocations
        $stmt = $db->prepare("SELECT COUNT(*) as cnt FROM allocations WHERE room_id = ? AND status = 'active'");
        $stmt->bind_param('i', $room_id);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();
        if ($row['cnt'] > 0) jsonResponse(['success' => false, 'message' => 'Cannot delete room with active allocations'], 400);
        $stmt = $db->prepare("DELETE FROM rooms WHERE id = ?");
        $stmt->bind_param('i', $room_id);
        $stmt->execute();
        jsonResponse(['success' => true, 'message' => 'Room deleted']);

    // ─── STUDENTS ───────────────────────────────────────────────────────
    case 'get_students':
        requireRole('rector');
        $db = getDB();
        $result = $db->query("
            SELECT u.id, u.full_name, u.email, u.student_id, u.phone, u.course, u.year_of_study,
                   r.room_number, r.floor, r.type as room_type, a.id as allocation_id, a.allocated_date
            FROM users u
            LEFT JOIN allocations a ON u.id = a.student_id AND a.status = 'active'
            LEFT JOIN rooms r ON a.room_id = r.id
            WHERE u.role = 'student'
            ORDER BY u.full_name
        ");
        $students = $result->fetch_all(MYSQLI_ASSOC);
        $db->close();
        jsonResponse(['success' => true, 'students' => $students]);

    case 'add_student':
        requireRole('rector');
        $full_name    = trim($input['full_name'] ?? '');
        $email        = trim($input['email'] ?? '');
        $password     = $input['password'] ?? 'student123';
        $student_id   = trim($input['student_id'] ?? '');
        $phone        = trim($input['phone'] ?? '');
        $course       = trim($input['course'] ?? '');
        $year         = intval($input['year_of_study'] ?? 1);

        if (!$full_name || !$email || !$student_id) {
            jsonResponse(['success' => false, 'message' => 'Name, email and student ID required'], 400);
        }

        $hashed = password_hash($password, PASSWORD_DEFAULT);
        $db     = getDB();
        $stmt   = $db->prepare("INSERT INTO users (full_name, email, password, role, student_id, phone, course, year_of_study) VALUES (?,?,?,'student',?,?,?,?)");
        $stmt->bind_param('ssssssi', $full_name, $email, $hashed, $student_id, $phone, $course, $year);
        if ($stmt->execute()) {
            jsonResponse(['success' => true, 'message' => 'Student added', 'id' => $db->insert_id]);
        } else {
            jsonResponse(['success' => false, 'message' => 'Email or Student ID already exists'], 409);
        }

    case 'delete_student':
        requireRole('rector');
        $sid  = intval($input['student_id'] ?? 0);
        $db   = getDB();
        $stmt = $db->prepare("DELETE FROM users WHERE id = ? AND role = 'student'");
        $stmt->bind_param('i', $sid);
        $stmt->execute();
        jsonResponse(['success' => true, 'message' => 'Student removed']);

    // ─── ALLOCATIONS ────────────────────────────────────────────────────
    case 'allocate_room':
        requireRole('rector');
        $student_id = intval($input['student_id'] ?? 0);
        $room_id    = intval($input['room_id'] ?? 0);
        $date       = $input['allocated_date'] ?? date('Y-m-d');
        $notes      = trim($input['notes'] ?? '');

        if (!$student_id || !$room_id) jsonResponse(['success' => false, 'message' => 'Student and room required'], 400);

        $db = getDB();

        // Check student not already allocated
        $stmt = $db->prepare("SELECT id FROM allocations WHERE student_id = ? AND status = 'active'");
        $stmt->bind_param('i', $student_id);
        $stmt->execute();
        if ($stmt->get_result()->num_rows > 0) {
            jsonResponse(['success' => false, 'message' => 'Student already has an active room allocation'], 409);
        }

        // Check room capacity
        $stmt = $db->prepare("SELECT capacity, occupied, status FROM rooms WHERE id = ?");
        $stmt->bind_param('i', $room_id);
        $stmt->execute();
        $room = $stmt->get_result()->fetch_assoc();
        if (!$room) jsonResponse(['success' => false, 'message' => 'Room not found'], 404);
        if ($room['status'] === 'maintenance') jsonResponse(['success' => false, 'message' => 'Room is under maintenance'], 400);
        if ($room['occupied'] >= $room['capacity']) jsonResponse(['success' => false, 'message' => 'Room is full'], 400);

        // Create allocation
        $rector_id = $_SESSION['user_id'];
        $stmt = $db->prepare("INSERT INTO allocations (student_id, room_id, allocated_by, allocated_date, notes) VALUES (?,?,?,?,?)");
        $stmt->bind_param('iiiss', $student_id, $room_id, $rector_id, $date, $notes);
        $stmt->execute();

        // Update room occupied count
        $new_occupied = $room['occupied'] + 1;
        $new_status   = ($new_occupied >= $room['capacity']) ? 'full' : 'available';
        $stmt = $db->prepare("UPDATE rooms SET occupied = ?, status = ? WHERE id = ?");
        $stmt->bind_param('isi', $new_occupied, $new_status, $room_id);
        $stmt->execute();

        $db->close();
        jsonResponse(['success' => true, 'message' => 'Room allocated successfully']);

    case 'deallocate_room':
        requireRole('rector');
        $allocation_id = intval($input['allocation_id'] ?? 0);
        if (!$allocation_id) jsonResponse(['success' => false, 'message' => 'Allocation ID required'], 400);

        $db = getDB();
        $stmt = $db->prepare("SELECT room_id FROM allocations WHERE id = ? AND status = 'active'");
        $stmt->bind_param('i', $allocation_id);
        $stmt->execute();
        $alloc = $stmt->get_result()->fetch_assoc();
        if (!$alloc) jsonResponse(['success' => false, 'message' => 'Active allocation not found'], 404);

        // Mark allocation as vacated
        $today = date('Y-m-d');
        $stmt  = $db->prepare("UPDATE allocations SET status = 'vacated', check_out_date = ? WHERE id = ?");
        $stmt->bind_param('si', $today, $allocation_id);
        $stmt->execute();

        // Decrease room occupied count
        $stmt = $db->prepare("UPDATE rooms SET occupied = GREATEST(0, occupied - 1), status = 'available' WHERE id = ?");
        $stmt->bind_param('i', $alloc['room_id']);
        $stmt->execute();

        $db->close();
        jsonResponse(['success' => true, 'message' => 'Room deallocated successfully']);

    case 'get_allocations':
        requireRole('rector');
        $db     = getDB();
        $result = $db->query("
            SELECT a.id, a.allocated_date, a.check_out_date, a.status, a.notes,
                   u.full_name, u.student_id as stu_id, u.email, u.course,
                   r.room_number, r.floor, r.type as room_type
            FROM allocations a
            JOIN users u ON a.student_id = u.id
            JOIN rooms r ON a.room_id = r.id
            ORDER BY a.created_at DESC
        ");
        $allocations = $result->fetch_all(MYSQLI_ASSOC);
        jsonResponse(['success' => true, 'allocations' => $allocations]);

    // ─── STUDENT: MY ROOM ────────────────────────────────────────────────
    case 'my_room':
        requireRole('student');
        $uid  = $_SESSION['user_id'];
        $db   = getDB();
        $stmt = $db->prepare("
            SELECT a.id as allocation_id, a.allocated_date, a.notes,
                   r.room_number, r.floor, r.type as room_type, r.capacity, r.occupied, r.amenities,
                   u_rector.full_name as rector_name
            FROM allocations a
            JOIN rooms r ON a.room_id = r.id
            JOIN users u_rector ON a.allocated_by = u_rector.id
            WHERE a.student_id = ? AND a.status = 'active'
            LIMIT 1
        ");
        $stmt->bind_param('i', $uid);
        $stmt->execute();
        $room = $stmt->get_result()->fetch_assoc();
        jsonResponse(['success' => true, 'room' => $room]);

    // ─── REQUESTS / COMPLAINTS ───────────────────────────────────────────
    case 'submit_request':
        requireRole('student');
        $subject = trim($input['subject'] ?? '');
        $message = trim($input['message'] ?? '');
        if (!$subject || !$message) jsonResponse(['success' => false, 'message' => 'Subject and message required'], 400);
        $uid  = $_SESSION['user_id'];
        $db   = getDB();
        $stmt = $db->prepare("INSERT INTO requests (student_id, subject, message) VALUES (?,?,?)");
        $stmt->bind_param('iss', $uid, $subject, $message);
        $stmt->execute();
        jsonResponse(['success' => true, 'message' => 'Request submitted successfully']);

    case 'my_requests':
        requireRole('student');
        $uid  = $_SESSION['user_id'];
        $db   = getDB();
        $stmt = $db->prepare("SELECT * FROM requests WHERE student_id = ? ORDER BY created_at DESC");
        $stmt->bind_param('i', $uid);
        $stmt->execute();
        $requests = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        jsonResponse(['success' => true, 'requests' => $requests]);

    case 'get_all_requests':
        requireRole('rector');
        $db     = getDB();
        $result = $db->query("
            SELECT r.*, u.full_name, u.student_id as stu_id, u.email
            FROM requests r
            JOIN users u ON r.student_id = u.id
            ORDER BY r.created_at DESC
        ");
        $requests = $result->fetch_all(MYSQLI_ASSOC);
        jsonResponse(['success' => true, 'requests' => $requests]);

    case 'respond_request':
        requireRole('rector');
        $req_id   = intval($input['request_id'] ?? 0);
        $response = trim($input['response'] ?? '');
        $status   = $input['status'] ?? 'in_progress';
        if (!$req_id || !$response) jsonResponse(['success' => false, 'message' => 'Request ID and response required'], 400);
        $db   = getDB();
        $stmt = $db->prepare("UPDATE requests SET rector_response = ?, status = ? WHERE id = ?");
        $stmt->bind_param('ssi', $response, $status, $req_id);
        $stmt->execute();
        jsonResponse(['success' => true, 'message' => 'Response sent']);

    // ─── NOTICES ────────────────────────────────────────────────────────
    case 'get_notices':
        requireLogin();
        $db     = getDB();
        $result = $db->query("SELECT n.*, u.full_name as posted_by_name FROM notices n JOIN users u ON n.posted_by = u.id ORDER BY n.created_at DESC LIMIT 10");
        $notices = $result->fetch_all(MYSQLI_ASSOC);
        jsonResponse(['success' => true, 'notices' => $notices]);

    case 'post_notice':
        requireRole('rector');
        $title   = trim($input['title'] ?? '');
        $content = trim($input['content'] ?? '');
        if (!$title || !$content) jsonResponse(['success' => false, 'message' => 'Title and content required'], 400);
        $uid  = $_SESSION['user_id'];
        $db   = getDB();
        $stmt = $db->prepare("INSERT INTO notices (title, content, posted_by) VALUES (?,?,?)");
        $stmt->bind_param('ssi', $title, $content, $uid);
        $stmt->execute();
        jsonResponse(['success' => true, 'message' => 'Notice posted']);

    case 'delete_notice':
        requireRole('rector');
        $nid  = intval($input['notice_id'] ?? 0);
        $db   = getDB();
        $stmt = $db->prepare("DELETE FROM notices WHERE id = ?");
        $stmt->bind_param('i', $nid);
        $stmt->execute();
        jsonResponse(['success' => true, 'message' => 'Notice deleted']);

    // ─── STATS ──────────────────────────────────────────────────────────
    case 'stats':
        requireRole('rector');
        $db = getDB();
        $stats = [];
        $stats['total_students']    = $db->query("SELECT COUNT(*) as c FROM users WHERE role='student'")->fetch_assoc()['c'];
        $stats['total_rooms']       = $db->query("SELECT COUNT(*) as c FROM rooms")->fetch_assoc()['c'];
        $stats['available_rooms']   = $db->query("SELECT COUNT(*) as c FROM rooms WHERE status='available'")->fetch_assoc()['c'];
        $stats['full_rooms']        = $db->query("SELECT COUNT(*) as c FROM rooms WHERE status='full'")->fetch_assoc()['c'];
        $stats['maintenance_rooms'] = $db->query("SELECT COUNT(*) as c FROM rooms WHERE status='maintenance'")->fetch_assoc()['c'];
        $stats['active_allocations']= $db->query("SELECT COUNT(*) as c FROM allocations WHERE status='active'")->fetch_assoc()['c'];
        $stats['unallocated']       = $db->query("SELECT COUNT(*) as c FROM users WHERE role='student' AND id NOT IN (SELECT student_id FROM allocations WHERE status='active')")->fetch_assoc()['c'];
        $stats['pending_requests']  = $db->query("SELECT COUNT(*) as c FROM requests WHERE status='pending'")->fetch_assoc()['c'];
        $db->close();
        jsonResponse(['success' => true, 'stats' => $stats]);

    default:
        jsonResponse(['success' => false, 'message' => 'Unknown action: ' . $action], 404);
}
