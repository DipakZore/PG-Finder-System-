-- Hostel Management System Database Setup
-- Run this file once to initialize the database

CREATE DATABASE IF NOT EXISTS hostel_db;
USE hostel_db;

-- Users Table (Students & Rector)
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role ENUM('student', 'rector') NOT NULL DEFAULT 'student',
    student_id VARCHAR(20) UNIQUE,
    phone VARCHAR(20),
    course VARCHAR(100),
    year_of_study INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Rooms Table
CREATE TABLE IF NOT EXISTS rooms (
    id INT AUTO_INCREMENT PRIMARY KEY,
    room_number VARCHAR(10) UNIQUE NOT NULL,
    floor INT NOT NULL,
    type ENUM('single', 'double', 'triple') NOT NULL DEFAULT 'single',
    capacity INT NOT NULL DEFAULT 1,
    occupied INT NOT NULL DEFAULT 0,
    amenities TEXT,
    status ENUM('available', 'full', 'maintenance') NOT NULL DEFAULT 'available',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Allocations Table
CREATE TABLE IF NOT EXISTS allocations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    room_id INT NOT NULL,
    allocated_by INT NOT NULL,
    allocated_date DATE NOT NULL,
    check_out_date DATE,
    status ENUM('active', 'vacated') NOT NULL DEFAULT 'active',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (room_id) REFERENCES rooms(id) ON DELETE CASCADE,
    FOREIGN KEY (allocated_by) REFERENCES users(id)
);

-- Complaints/Requests Table
CREATE TABLE IF NOT EXISTS requests (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    subject VARCHAR(200) NOT NULL,
    message TEXT NOT NULL,
    status ENUM('pending', 'in_progress', 'resolved') DEFAULT 'pending',
    rector_response TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Notices Table
CREATE TABLE IF NOT EXISTS notices (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    content TEXT NOT NULL,
    posted_by INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (posted_by) REFERENCES users(id)
);

-- Seed: Default Rector Account (password: rector123)
INSERT IGNORE INTO users (full_name, email, password, role) VALUES
('Dr. Robert Mitchell', 'rector@hostel.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'rector');

-- Note: The password above is bcrypt hash of 'rector123'
-- For demo, we use password_verify() in PHP

-- Seed: Sample Rooms
INSERT IGNORE INTO rooms (room_number, floor, type, capacity, amenities, status) VALUES
('101', 1, 'single', 1, 'Wi-Fi, Desk, Wardrobe, AC', 'available'),
('102', 1, 'single', 1, 'Wi-Fi, Desk, Wardrobe, AC', 'available'),
('103', 1, 'double', 2, 'Wi-Fi, Desk, Wardrobe, AC, Balcony', 'available'),
('104', 1, 'double', 2, 'Wi-Fi, Desk, Wardrobe', 'available'),
('201', 2, 'single', 1, 'Wi-Fi, Desk, Wardrobe, AC', 'available'),
('202', 2, 'single', 1, 'Wi-Fi, Desk, Wardrobe, AC', 'available'),
('203', 2, 'double', 2, 'Wi-Fi, Desk, Wardrobe, AC', 'available'),
('204', 2, 'triple', 3, 'Wi-Fi, Desk, Wardrobe, Balcony', 'available'),
('301', 3, 'single', 1, 'Wi-Fi, Desk, Wardrobe, AC, Mountain View', 'available'),
('302', 3, 'double', 2, 'Wi-Fi, Desk, Wardrobe, AC, Mountain View', 'available'),
('303', 3, 'triple', 3, 'Wi-Fi, Desk, Wardrobe', 'available'),
('304', 3, 'single', 1, 'Wi-Fi, Desk, Wardrobe', 'maintenance');

-- Seed: Sample Students (password: student123 for all)
INSERT IGNORE INTO users (full_name, email, password, role, student_id, phone, course, year_of_study) VALUES
('Alice Johnson', 'alice@student.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'student', 'STU001', '555-0101', 'Computer Science', 2),
('Bob Williams', 'bob@student.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'student', 'STU002', '555-0102', 'Electrical Engineering', 3),
('Carol Davis', 'carol@student.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'student', 'STU003', '555-0103', 'Business Administration', 1),
('David Brown', 'david@student.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'student', 'STU004', '555-0104', 'Mechanical Engineering', 4),
('Eve Taylor', 'eve@student.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'student', 'STU005', '555-0105', 'Architecture', 2);

-- Seed: Sample Notice
INSERT IGNORE INTO notices (title, content, posted_by) VALUES
('Welcome to Hostel Management System', 'Welcome to the new digital hostel management portal. Please ensure your profile is up to date. Contact the rector for any room-related queries.', 1),
('Hostel Rules & Regulations', 'Quiet hours are from 10 PM to 6 AM. Common areas must be kept clean. Visitors must sign in at the reception.', 1);
